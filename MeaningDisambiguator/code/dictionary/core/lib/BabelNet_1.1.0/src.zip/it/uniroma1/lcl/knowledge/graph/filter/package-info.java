/**
 * Package including all classes used to filter
 * {@link it.uniroma1.lcl.knowledge.graph.KnowledgeGraph}s.
 */
package it.uniroma1.lcl.knowledge.graph.filter;