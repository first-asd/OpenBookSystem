/**
 * The root package of the Knowledge graph API. For more information start by
 * looking at the utility methods defined in 
 * {@link it.uniroma1.lcl.knowledge.graph.KnowledgeGraphUtils}.
 */
package it.uniroma1.lcl.knowledge;