/**
 * The root package of the BabelNet API. For more information start by looking
 * at the main access point to BabelNet, defined in the
 * {@link it.uniroma1.lcl.babelnet.BabelNet} class.
 */
package it.uniroma1.lcl.babelnet;