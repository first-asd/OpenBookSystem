/**
 * Package to work with custom {@link it.uniroma1.lcl.knowledge.KnowledgeBase}s.
 */
package it.uniroma1.lcl.knowledge.custom;