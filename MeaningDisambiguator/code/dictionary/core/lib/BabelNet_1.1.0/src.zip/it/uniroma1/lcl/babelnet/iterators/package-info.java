/**
 * Package including all classes related to {@link java.util.Iterator}s for
 * BabelNet
 */
package it.uniroma1.lcl.babelnet.iterators;