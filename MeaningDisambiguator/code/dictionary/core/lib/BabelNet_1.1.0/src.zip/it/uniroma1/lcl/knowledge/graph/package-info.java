/**
 * Package including all classes related to
 * {@link it.uniroma1.lcl.knowledge.graph.KnowledgeGraph}s.
 */
package it.uniroma1.lcl.knowledge.graph;