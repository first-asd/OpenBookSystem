/* Copyright © 2008 José M. Gómez
 *
 * This file is part of XMLUtils.
 *
 * XMLUtils is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * XMLUtils is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.</p>
 * You should have received a copy of the GNU Lesser General Public License
 * along with XMLUtils.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.upv.xmlutils;

import java.util.ArrayList;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/** A NodeList to store XML elements.
 *
 * @author jmgomez
 */
class ElementNodeList implements NodeList {
	/** An array list when the elements will be stored. */
    private ArrayList<Node> elements = new ArrayList<Node>();

    @Override
    public Node item(int i) {
        return elements.get(i);
    }
    @Override
    public int getLength() {
        return elements.size();
    }
    /** Add a node to this node list.
	 *
	 * @param node the node to add
	 * @return true if this collection changed as a result of the call
	 */
    public boolean append(Node node) {
        return elements.add(node);
    }
    
}
