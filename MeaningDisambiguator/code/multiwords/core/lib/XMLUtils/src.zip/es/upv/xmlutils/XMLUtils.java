/* Copyright © 2008 José M. Gómez
 *
 * This file is part of XMLUtils.
 *
 * XMLUtils is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.</p>
 *
 * XMLUtils is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.</p>
 * You should have received a copy of the GNU Lesser General Public License
 * along with XMLUtils.  If not, see &lt;http://www.gnu.org/licenses/&gt;.
 */
package es.upv.xmlutils;

import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.CharArrayReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * Title:        XML tools.
 * Description:  Set of XML tools to make easy the document processing.
 * Copyright:    Copyright (c) 2002
 * Company:      Departamento de Sistemas Informáticos y Computación.
 * @author José Manuel Gómez Soriano
 * @version 2.0
 **/
public class XMLUtils {
    /** Load a xml document stored in a file.
     * @param fileName The path to the xml file.
     * @return The xml document.
	 * @throws IOException If any IO errors occur.
	 * @throws SAXException If any parse errors occur.
	 * @throws ParserConfigurationException If a DocumentBuilder cannot be created which satisfies the configuration requested.
	 * @throws FileNotFoundException if the file does not exist, is a directory rather than a regular file, or for some other reason cannot be opened for reading.
	 *
     */
    static public Document loadXML(String fileName) throws FileNotFoundException, IOException, ParserConfigurationException, SAXException {
        FileInputStream fis = new FileInputStream(fileName);
        Document doc = readXML(new BufferedInputStream(fis));
        fis.close();
        return doc;
    }
    /** Read a XML document from a string.
     * @param doc String with the XML document.
     * @param encoding Text encoding of the string.
     * @return The XML document.
	 * @throws IOException If any IO errors occur.
	 * @throws SAXException If any parse errors occur.
	 * @throws ParserConfigurationException If a DocumentBuilder cannot be created which satisfies the configuration requested.
     */
    static public Document readXML(String doc, String encoding) throws IOException, ParserConfigurationException, SAXException {
        ByteArrayInputStream bais = new ByteArrayInputStream(doc.getBytes(encoding));
        Document xdoc = readXML(bais);
        bais.close();
        return xdoc;
    }
    /** Read a XML document from a string without specify any text encoding.
     * @param doc String with the XML document.
     * @return The XML document.
	 * @throws IOException If any IO errors occur.
	 * @throws SAXException If any parse errors occur.
	 * @throws ParserConfigurationException If a DocumentBuilder cannot be created which satisfies the configuration requested.
     */
    static public Document readXML(String doc) throws IOException, ParserConfigurationException, SAXException {
        CharArrayReader car = new CharArrayReader(doc.toCharArray());
        Document xdoc = readXML(car);
        car.close();
        return xdoc;
    }
    /**
	 * Read a XML document from a byte stream.
     * @param is The byte stream to read.
     * @return XML document.
	 * @throws IOException If any IO errors occur.
	 * @throws SAXException If any parse errors occur.
	 * @throws IllegalArgumentException When is is null.
	 * @throws ParserConfigurationException If a DocumentBuilder cannot be created which satisfies the configuration requested.
     */
    static public Document readXML(InputStream is) throws IOException, ParserConfigurationException, SAXException {
        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = documentBuilder.parse(is);
        return doc;
    }
    /** Read a XML document from a character stream.
     * @param r The character stream.
     * @return XML document.
	 * @throws IOException If any IO errors occur.
	 * @throws SAXException If any parse errors occur.
	 * @throws IllegalArgumentException When r is null.
	 * @throws ParserConfigurationException If a DocumentBuilder cannot be created which satisfies the configuration requested.
     */
    static public Document readXML(Reader r) throws IOException, ParserConfigurationException, SAXException {
        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = documentBuilder.parse(new InputSource(r));
        return doc;
    }
    /** Search a direct child by means of a given attribute value.
     *  @param parent The father element.
     *  @param attributeName The attribute to comapare.
     *  @param attributeValue The attribute value to search.
     *  @return Return the element if it is found, <b>null</b> otherwise.
     */
    static public Element getElementByAttribute(Element parent, String attributeName, String attributeValue) {
        // For each child
        for(Node node = parent.getFirstChild(); node != null; node = node.getNextSibling())
            // Check if it is a Element node
            if( node.getNodeType() == node.ELEMENT_NODE) {
                // Get the attribute value of this element
                String att = ((Element)node).getAttribute(attributeName);
                // Compare the values, if they are equal return the element
                if(att != null && attributeValue != null && att.equals(attributeValue))
                    return (Element)node;
            }
        // Return null if the element is not found
        return null;
    }
    /** Returns the first Element match through the immediate Child Element Nodes.
     * Only immediate children are searched (i.e. no grandchildren).
     * The specified qualified name refers to the Element tag name (see Namespace for details).
     * @param parent The parent of the elements.
     * @param name Qualified name to match against in immediate children.
     * @return The first matching Element Node, or null if no matches.
    */
    static public Element getElementNamed(Element parent, String name) {
        for(Node node = parent.getFirstChild(); node != null; node = node.getNextSibling())
            if(node.getNodeType() == node.ELEMENT_NODE && node.getNodeName().equals(name))
                return (Element)node;
        return null;
    }
    /** Returns a NodeList of all matches through the immediate child Element Nodes.
     * Only immediate children are searched (i.e. no grandchildren).
     * The specified qualified name refers to the Element tag name (see Namespace for details).
     *
     * @param parent The parent of the elements.
     * @param name Qualified name to match against in immediate children.
     * @return A NodeList of matches, or an empty NodeList if no matches.
     */
    static public NodeList getElementsNamed(Element parent, String name) {
        ElementNodeList nl = new ElementNodeList();
        for(Node node = parent.getFirstChild(); node != null; node = node.getNextSibling())
            if(node.getNodeType() == node.ELEMENT_NODE && node.getNodeName().equals(name))
                nl.append(node);
        return nl;
    }
    /** Search recursivelly a element by the specified attribute.
     *  @param parent The parent of the elements which the search is started.
     *  @param attributeName The attribute to comapare.
     *  @param value The attribute value to search.
     *  @return The first matching Element Node, or null if no matches.
     *   The search is first in depth.
     */
    static public Element searchElementByAttribute(Element parent, String attributeName, String value) {
        // Check if the value is not null
        if (value == null) return null;
        // For each child
        NodeList list = parent.getChildNodes();
        for (int i = 0; i < list.getLength(); i++) 
            // If the child is a ELEMENT
            if (list.item(i).getNodeType() == Node.ELEMENT_NODE) {
                // Get the element
                Element elem = (Element) list.item(i);
                // If it has the attribute with that value return it
                if (value.equals(elem.getAttribute(attributeName)))
                    return elem;
                else 
                    // Search in the children of this child
                    if (elem.hasChildNodes()) {
                        elem = searchElementByAttribute(elem, attributeName, value);
                        if (elem != null) return elem;
                    }
            }
        // If does not found anything, return null
        return null;
    }
    /** Saves XML Document into XML file.
     * @param fileName XML file name.
     * @param doc XML document to print.
     * @param encoding The file encoding.
     * @throws IOException If any IO errors occur.
     */    
    static public void saveXML(Document doc, String fileName, String encoding)  throws IOException {
        // Open output stream where XML Document will be saved
        Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), encoding));
        try {
            printXML(writer, doc, encoding);
        } finally {
            writer.close();
        }
    }
    /** Saves XML Document into XML file in the system encoding.
     * @param fileName XML file name.
     * @param doc XML document to print.
     * @throws IOException If any IO errors occur.
     */    
    static public void saveXML(Document doc, String fileName) throws IOException {
        // Obtain the system encoding
        String encoding = Charset.forName(System.getProperty("file.encoding")).name();
		if(encoding == null){
            encoding = "UTF-8";
        }
		// Open output stream where XML Document will be saved
        Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName), encoding));
        printXML(writer, doc, encoding);

        writer.close();
        
    }
    
    /** Print the XML document on the standard output.
     * @param doc XML document to print.
     * @param encoding The XML document encoding.
     * @throws IOException If any IO errors occur.
     */
    static public void printXML(Document doc, String encoding) throws IOException {
        printXML(System.out, doc, encoding);
    }
    
    /** Print the XML document on the standard output with the system encoding.
     * @param doc XML document to print.
     * @throws IOException If any IO errors occur.
     */
    static public void printXML(Document doc) throws IOException {
		// Obtain the system encoding
		String encoding = Charset.forName(System.getProperty("file.encoding")).name();
		if(encoding == null){
            encoding = "UTF-8";
        }
        printXML(System.out, doc, encoding);
    }
    
    /** Print the XML document on the standard output the specified byte stream.
     * @param os Byte stream to write the information.
     * @param doc XML document to print.
     * @param encoding The XML document encoding.
     * @throws IOException If any IO errors occur.
     */
    static public void printXML(OutputStream os, Document doc, String encoding) throws IOException {
        Writer w = new OutputStreamWriter(os, encoding);
        printXML(w,doc, encoding);
    }
    
    /** Print a XML Document into a character stream.
     * @param writer Character stream to print the document.
     * @param doc XML document to print.
     * @param encoding The encoding to use in the document.
     * @throws IOException If any IO errors occur.
     */    
    static public void printXML(Writer writer, Document doc, String encoding) throws IOException {
        XMLSerializer serializer = new XMLSerializer();
        OutputFormat outputFormat = new OutputFormat();
         // Set the xml format
        outputFormat.setEncoding(encoding);
        outputFormat.setVersion("1.0");
        outputFormat.setIndenting(true);
        outputFormat.setIndent(4);
        // Define an object where the code is generated
        serializer.setOutputCharStream(writer);
        // Apply the format
        serializer.setOutputFormat(outputFormat);
        // Serialize the XML document
        serializer.serialize(doc);
    }

    /** Print a XML Document into a character stream in "UTF-8" encoding.
     * @param writer Character stream to print the document.
     * @param doc XML document to print.
     * @throws IOException If any IO errors occur.
	 * @deprecated As is impossible to be sure that the encoding of this writer it is UTF-8 is better use {@link #printXML(Writer, Document, String) printXML}.
     */    
    static public void printXML(Writer writer, Document doc) throws IOException {
        printXML(writer, doc, "UTF-8");
    }
    
    /** Return a string which represents the XML document.
     * @param doc XML document to return.
     * @param encoding The charset encoding.
     * @throws IOException If any IO errors occur.
     */
    static public String toString(Document doc, String encoding) throws IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		printXML(new OutputStreamWriter(baos, encoding), doc, encoding);
        return baos.toString(encoding);
    }
    
    /** Return a string which represents the XML document.
     * @param doc XML document to return.
     * @throws IOException If any IO errors occur.
     */    
    static public String toString(Document doc) throws IOException {
		// Obtain the system encoding
		String encoding = Charset.forName(System.getProperty("file.encoding")).name();
		if(encoding == null){
            encoding = "UTF-8";
        }
		return toString(new StringWriter(), doc, encoding);
    }

	/** Return a string which represents the XML document.
	 * @param writer the string writer to which the XML string is temporally stored.
     * @param doc XML document to return.
     * @param encoding The charset encoding.
     * @throws IOException If any IO errors occur.
     */
    static public String toString(StringWriter writer, Document doc, String encoding) throws IOException {
		printXML(writer, doc, encoding);
        return writer.toString();
    }
}

